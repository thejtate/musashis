<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
<table cellspacing="0" cellpadding="0" width="600px">
	<thead>
		<tr>
			<td background="images/header-bg.jpg" height="125px" align="center"><a href="#"><img style="display: block; border: none;" src="images/logo.png" alt="logo"/></a></td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td background="images/body-bg.jpg">
				<table cellspacing="0" cellpadding="0" width="100%">
					<thead>
						<tr>
							<td background="images/body-header-bg.jpg" height="50px" width="600px"></td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<table cellspacing="0" cellpadding="0" width="100%" background="images/body-body-bg.jpg" style="padding: 0 14px 0 29px; vertical-align: top;">
									<tbody>
										<tr>
											<td style="padding-right: 28px; vertical-align: top;">
												<p style="color: #333333; font: bold 34px/38px Sans; margin: 0 0 10px;">Would you like to try our Sushi Party To go Trays?</p>
												<p style="color: #333333; font: 13px/18px Arial, sans-serif; text-transform: uppercase; margin: 0 0 15px;">We have various Sushi Party trays to select for various special occasions: Game parties, Baby showers or Weekend Get-togethers.</p>
												<img style="margin: 0 0 15px; display: block; border: none;" src="images/tmp_1.png" alt=""/>
												<p style="color: #402313; font: 14px/16px Sans; margin: 0 0 5px; text-transform: uppercase;">SUSHI SMALL TRAY $40</p>
												<p style="color: #402313; font: 12px/18px Sans; margin: 0 0 10px;">California Roll,NY Roll,Tuna Roll,Tootsie Roll,Shrimp Nigiri,Salmon Nigiri,Freshwater eel Nigiri and Edamame</p>
												<p style="color: #402313; font: 14px/16px Sans; margin: 0 0 5px; text-transform: uppercase;">SUSHI DELUXE TRAY $60</p>
												<p style="color: #402313; font: 12px/18px Sans; margin: 0 0 10px;">Yakitori Robata Sirlon Robata, Bacon Asparagus Robata,Veggie Robata,California Roll, NY Roll, Tuna Roll, Tootsie Roll, Shrimp Nigiri,Salmon Nigiri, Freshwater eel Nigiri and Edamame</p>
												<p style="color: #402313; font: 14px/16px Sans; margin: 0 0 5px; text-transform: uppercase;">SUSHI LARGE TRAY $80</p>
												<p style="color: #402313; font: 12px/18px Sans; margin: 0 0 10px;">Yakitori Robata, Sirlon Robata, Bacon Asparagus Robata, Veggie Robata, Asain sausage Robata, California Roll, NY Roll, Tuna Roll, Tootsie Roll, Shrimp Nigiri, Salmon Nigiri, Freshwater eel Nigiri,1 Special roll(value of $14) and Edamame</p>
											</td>
											<td width="186px" style="vertical-align: top;">
												<table cellspacing="0" cellpadding="0" width="100%" style="color: #99938a;">
													<thead>
														<tr>
															<td background="images/body-sidebar-header-bg.png" height="48px" width="186px"></td>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td background="images/body-sidebar-body-bg.jpg" width="186px" align="center">
																<p style="font: bold 18px/22px Arial, sans-serif; margin: 0 0 13px;">Earn the following <br> coupon for your <br> next visit:</p>

																<p style="font: bold 13px/18px Arial, sans-serif; margin: 0 0 3px; text-transform: uppercase;">Spend</p>
																<p style="font: bold 16px/22px Arial, sans-serif; margin: 0 0 3px; text-transform: uppercase;">$100-$299</p>
																<p style="font: 16px/18px Arial, sans-serif; margin: 0 0 20px; font-style: italic; text-transform: uppercase;">10% Coupon</p>

																<p style="font: bold 16px/22px Arial, sans-serif; margin: 0 0 3px; text-transform: uppercase;">$300-$499</p>
																<p style="font: 16px/18px Arial, sans-serif; margin: 0 0 20px; font-style: italic; text-transform: uppercase;">15% Coupon</p>

																<p style="font: bold 16px/22px Arial, sans-serif; margin: 0 0 3px; text-transform: uppercase;">Over $500</p>
																<p style="font: 16px/18px Arial, sans-serif; margin: 0 0 20px; font-style: italic; text-transform: uppercase;">20% Coupon</p>

																<p style="font: bold 12px/14px Arial, sans-serif; margin: 0 0 25px;">Plus: Reward Card <br> Members earn double <br> bonus points for each <br> dollar spent during these <br> two weeks</p>
																<p style="font: 10px/12px Arial, sans-serif; margin: 0"><strong style="font-weight: bold;">Note:</strong> Purchasing giftcards is not <br> included in this special bonus <br> coupon program. Coupon cannot <br> combine with any other offer, is <br> not valid during Happy Hour, <br> cannot be redeemed as cash or <br> gratuity and cannot apply to <br> alcoholic beverages.</p>
															</td>
														</tr>
													</tbody>
													<tfoot>
														<tr>
															<td background="images/body-sidebar-footer-bg.png" height="32px" width="186px"></td>
														</tr>
													</tfoot>
												</table>
											</td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td background="images/body-footer-bg.jpg" height="47px" width="600px"></td>
						</tr>
					</tfoot>
				</table>
			</td>
		</tr>
	</tbody>
  <tfoot>
  <tr>
    <td background="images/footer-bg.jpg" height="125px" style="vertical-align: bottom;">
      <table cellspacing="0" cellpadding="0" width="100%">
        <tbody>
        <tr align="center">
          <td style="padding-top: 10px;">
            <a href="#"><img style="display: block; border: none;" src="images/btn-reservation.png" alt=""/></a>
          </td>
          <td style="padding-top: 10px; padding-right: 25px;">
            <a href="#"><img style="display: inline; border: none;" src="images/social-1.png" alt=""/></a>
            <a href="#"><img style="display: inline; border: none;" src="images/social-2.png" alt=""/></a>
            <a href="#"><img style="display: inline; border: none;" src="images/social-3.png" alt=""/></a>
          </td>
          <td align="left" style="padding-top: 10px;">
            <p style="color: #dbcbaf; font: 13px/18px Arial, sans-serif;">4318 N. Western <br>
              Oklahoma City, OK 73118 </p>
          </td>
        </tr>
        <tr align="center">
          <td colspan="3" style="vertical-align: bottom;"><a href="#"><img style="display: block; border: none;" src="images/logo-footer.png" alt=""/></a></td>
        </tr>
        </tbody>
      </table>
    </td>
  </tr>
  <tr>
    <td style="height: 37px; background: #000;">
      <table cellspacing="0" cellpadding="0" width="100%">
        <tbody>
        <tr align="center">
          <td><a href="#"><img style="display: block; border: none;" src="images/title-sushi-neko.png" alt=""/></a></td>
          <td><a href="#"><img style="display: block; border: none;" src="images/title-musashis.png" alt=""/></a></td>
          <td><a href="#"><img style="display: block; border: none;" src="images/title-will-rogers.png" alt=""/></a></td>
          <td><a href="#"><img style="display: block; border: none;" src="images/title-lobby.png" alt=""/></a></td>
          <td><a href="#"><img style="display: block; border: none;" src="images/title-coach-house.png" alt=""/></a></td>
          <td><a href="#"><img style="display: block; border: none;" src="images/title-tasting-room.png" alt=""/></a></td>
        </tr>
        </tbody>
      </table>
    </td>
  </tr>
  </tfoot>
</table>
</body>
</html>